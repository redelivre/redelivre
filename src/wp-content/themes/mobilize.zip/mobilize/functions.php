<?php
class Ethymos{
	

    
	
	/**
	* Registra actions do wordpress
	*
	*/
	public function __construct(){
		
		add_action('wp_enqueue_scripts', array($this, 'css'));		
		add_action('wp_enqueue_scripts', array($this, 'javascript'));
		
	/**
    * Widgets
	*
	*/
		
		if ( function_exists('register_sidebar') )
			register_sidebar(array(
					'name' => 'sidebar',
					'before_widget' => '<div class="sidebar-box">',
					'after_widget' => '</div>',
					'before_title' => '<h2>',
					'after_title' => '</h2>',
			));
	}
	
	/**
	* Fun��o respons�vel por controlar as folhas de estilo do site
	*
	*/
	public function css(){
		$path = get_template_directory_uri() . '/css';
		wp_register_style('bootstrap-responsive', $path . '/bootstrap-responsive.min.css');
		wp_register_style('bootstrap', $path . '/bootstrap.min.css');		
		wp_register_style('geral', get_stylesheet_directory_uri() . '/style.css', array('bootstrap'));
		
		wp_enqueue_style('bootstrap');
		wp_enqueue_style('bootstrap-responsive');
		wp_enqueue_style('geral');		
	}
	
	/**
	* Controla os arquivos javascript do site
	*
	*/
	public function javascript(){
		$path = get_template_directory_uri() . '/js';
		wp_register_script('bootstrap', $path . '/bootstrap.min.js');
		wp_enqueue_script('jquery');
		wp_enqueue_script('bootstrap');
		
		
		
	}
}

$ethymos = new Ethymos();