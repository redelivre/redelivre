<?php get_header(); ?>
 <div class="container">
	 <div class="row">
		<div class="span12 miolo">
			<div class="banner">
				<img src="<?php echo get_template_directory_uri()."/imagens/banner.jpg"; ?>" alt="mobilize" />
			</div>
			
			<div class="span4 info">
			Aqui um espaço para apresentar sua organização e formar sua rede de apoiadores, um destaque médio parece adequado.
			</div>			
			<div class="span8 destaques">
			
			 <div class="dest">
				<div class="title-dest">
					<!-- título do post  php the_title() -->
					<h1>Folha abre inscrições para prêmios socioambientais</h1>	
				</div>
				
				<div class="img-dest">
					<!-- imagem do post destaque -->
					<img src="<?php echo get_template_directory_uri()."/imagens/destaque.png"; ?>" alt="mobilize" />
				</div>
				
				<div class="dest-date">	
					<?php the_time("d/m/Y")?>
				</div>
				
				<div class="dest-descript">
					<!-- the_excerpt() -->
					 <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus purus sapien, euismod in imperdiet eu, convallis et tellus. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Quisque vel orci tellus.       </p>
			    	<a href="">Leia mais</a>
			    </div>
			</div>
			
			<div class="buttons">
				<div class="button-a">
				<
				</div>
				<div class="button-b">
				>
				</div>
			</div>
			</div>
			
			<div class="span4 widgets">
			
			<?php get_sidebar()?>
			
<!-- 				<div class="wid-contribua">
						<h2>+ Contribua </h2>
					<div class="wid">
						<p>Lorem ipsum dolor sit amet,  ectetur adipiscing elit. Vivamus purus  pien, euismod in imperdiet eu, convallis et tellus...</p>
						<a href=""> QUERO CONTRIBUIR</a>
					</div>
				</div>
				
				<div class="wid-informativo">
					<h2>+ Informativo </h2>
						<div class="wid">
							<p>Lorem ipsum dolor sit amet,  ectetur adipiscing elit. Vivamus purus  pien, euismod in imperdiet eu, convallis et tellus...</p>
							<form action="demo_form.asp">
  								<input type="text" name="fname" value="Digite seu email e aperte enter"><br>
  							</form> 
							
						</div>
				</div>
				
				<div class="wid-agenda">
					<h2>+ Agenda </h2>
						<div class="wid">
							<div class="ag-um">
								<h3>08/04/2013</h3>
									<p>Ato contra violência, Curitiba.</p>
							</div>
							<div class="ag-dois">
								<h3>08/04/2013</h3>
									<p>Ato contra violência, Curitiba.</p>
							</div>
								<a href="">VER LISTA COMPLETA</a>
						</div>
				</div>
				 -->
			
			</div>
			
			<div class="span7 sub-destaques">
			
			<div class="title-sub-dest">
				+DESTAQUES
			</div>
					<div class="not-1 span7">
						<div class="sub-dest-img">
							<img src="imagens/foto.jpg" alt="" />
						</div>
						
						<div class="sub-dest-tex">
						   <h2>Folha abre inscrições para prêmios socioambientais</h2>
						</div>
						
						<div class="sub-dest-desc">
						   <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
						</div>
						
						<a href="" class="sub-dest-seguir">Continue lendo</a>
					</div>
					
					<div class="not-2">
						<div class="sub-dest-img">
							<img src="imagens/foto.jpg" alt="" />
						</div>
						
						<div class="sub-dest-tex">
						   <h2>Folha abre inscrições para prêmios socioambientais</h2>
						</div>
						
						<div class="sub-dest-desc">
						   <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
						</div>
						
						<a href="" class="sub-dest-seguir">Continue lendo</a>
					
					</div>
					
					<div class="not-3">
						<div class="sub-dest-img">
							<img src="imagens/foto.jpg" alt="" />
						</div>
						
						<div class="sub-dest-tex">
						   <h2>Folha abre inscrições para prêmios socioambientais</h2>
						</div>
						
						<div class="sub-dest-desc">
						   <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. </p>
						</div>
						
						<a href="" class="sub-dest-seguir">Continue lendo</a>
					</div>
			</div>
		</div>
	</div>
 </div>
 
 

<?php get_footer(); ?>