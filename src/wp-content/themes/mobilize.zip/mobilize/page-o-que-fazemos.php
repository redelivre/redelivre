<?php get_header(); ?>
<div class="row">
		<div class="container">
			<div class="miolo">
				<div class="span4">
					<?php get_sidebar(); ?>
				</div>
				
				<div class="quem-somos span7">
					<div class="cabecalho">
						<h2>O que fazemos</h2>
						<h3>Conheça nossas açoes</h3>
					</div>
						
					<div class="logo">
						
					</div>
					
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi erat tortor, sagittis ac vehicula sed, iaculis et nunc. Nulla dapibus ante sed est rhoncus vitae porta dui tincidunt. Donec sagittis ornare lacus, ac faucibus lacus ultrices at. Sed ac ipsum eget libero posuere ultrices. Nunc sem arcu, volutpat eu porta quis, imperdiet et purus. Vivamus aliquet, magna non commodo placerat, lectus ante bibendum lorem, in pellentesque enim neque ac augue. Aenean laoreet dolor aliquet nisi semper sed dapibus purus mattis. Nullam tincidunt lobortis mi vel lacinia. Maecenas semper volutpat lacus, non egestas mauris scelerisque at. Duis laoreet elementum massa sed congue. Aliquam erat volutpat. In pharetra posuere volutpat. Duis tincidunt sem sit amet elit placerat vehicula. Pellentesque accumsan nunc neque, at congue lorem. Etiam volutpat vehicula lectus, ac bibendum nibh semper sed.

						Nunc scelerisque commodo suscipit. Morbi a sem a augue faucibus volutpat nec ac justo. Etiam posuere gravida augue pellentesque bibendum. Aenean lobortis tristique enim at congue. Donec gravida velit non purus placerat in dictum ante tincidunt. Donec malesuada imperdiet tincidunt. Aliquam erat volutpat. Donec posuere lobortis quam, euismod tincidunt risus laoreet aliquam. Quisque vel tortor risus, non venenatis purus. Morbi ullamcorper pharetra ipsum, sed ultrices nunc suscipit nec. Nunc posuere commodo sem sed porta. Curabitur auctor posuere pulvinar.</p>
				
					<div class="equipe">
						<div class="cabecalho">	
							<h2>Equipe</h2>
						</div>
						
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reiciendis eius quisquam fugit esse culpa optio fuga voluptas consequatur! Voluptatibus illum sequi eveniet aperiam. Molestiae voluptatem cumque dignissimos ut recusandae officiis.</p>
						
						
						<div class="person">
							<div class="person-img">
								<img src="<?php echo get_template_directory_uri()."/imagens/foto.png"; ?>" alt="mobilize" />
							</div>
							
						<div class="des-person">
							<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptate expedita sed distinctio mollitia enim eum eligendi nesciunt totam facilis vitae maiores incidunt assumenda ipsa quod sequi consequatur saepe accusamus quam!</p>
							<a href="">facebook</a>
							<a href="">twitter</a>
						</div>
						
						</div>
					</div>
									
				
				</div>
			</div>	
				
        </div>	
	</div>
<?php get_footer; ?>