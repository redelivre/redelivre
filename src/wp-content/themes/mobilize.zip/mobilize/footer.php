

<?php wp_footer(); ?>
<div class="masterfooter">
	<div class="container">
		<div class="span4 fot-1">
		Lorem ipsum dolor sit amet, consectetur adipisicing elit. Iure explicabo aliquid deserunt illo beatae amet est debitis alias ipsum veniam laborum dicta nisi dolorum inventore accusamus aperiam rem dolor repellat?
		</div>
		
		<div class="span4 fot-2">
			<div class="navigator">
				<h5>O que você procura?</h5>
				<a href="">Capa</a>
				<a href="">Quem somos</a>
				<a href="">O que fazemos</a>
				<a href="">Mobilize</a>
				<a href="">Contato</a>
			</div>
		</div>
		
		<div class="span4 fot-3">
			
		</div>
	</div>
</div>

<div class="container">
	<div class="endereco">
	<!-- aqui a do tema de colocar informações no rodapé -->
	Mobilize Rua Itupava 1299 conjunto 312 Hogo Lange Curitiba PR
	</div>
	
	
</div>
</body>
</html>