<form action="<?php echo home_url() ?>" id="searchform" method="get" role="search">
	<div>
		<label for="s"> </label>
		<input type="text" id="s" name="s" value="Digite sua busca e aperte enter">
	</div>
</form>