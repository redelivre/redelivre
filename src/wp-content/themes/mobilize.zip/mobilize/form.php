<label for="<?php echo $this->get_field_id("descricao-widget"); ?>">Descrição do seu campo de texto</label>
<textarea name="<?php echo $this->get_field_name("descricao-widget"); ?>" id="<?php echo $this->get_field_id ("descricao-widget"); ?>" cols="30" rows="10"></textarea>

