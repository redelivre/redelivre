<!doctype html>
<html>
  <head>
    <title>
	    
	    <?php
	    if(is_home()){
			echo get_bloginfo('name') . ' - ' . get_bloginfo('description');
	    } else {
		    wp_title();
		    bloginfo('name');
	    }
	    ?>
	    
	    
    </title>
    <meta charset="utf-8" />

    <!-- meta/rss/trackacks -->
    <link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php bloginfo('rss2_url'); ?>" />
    <link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
    
    <!-- fonte -->
    <link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>

    <!-- wp-head -->
    <?php wp_head(); ?>
</head>

<body>

	<header id="masterheader">
	    <div class="container">
	    <div class="row header">
	        <div class="span4">
	        	<div class="brand">
	            	<img src="<?php echo get_template_directory_uri()."/imagens/brand.png"; ?>" alt="mobilize" />
	            </div>
	        </div>
	        <div class="span4 offset4">
		        	
		        	<div class="social">
		              <?php do_action('campanha_body_header'); ?>
		             </div> 
	              	<div class="busca">
	             		<?php get_search_form(); ?>
	             	</div>
	        </div>   
	        </div>
	    </div>
	    </div>
	
	    <div class="menu">
	        <div class="container">
	         <div class="main-menu">
	            <?php wp_nav_menu( array( 'menu' => 'main', 'theme_location' => 'primary' ) ); ?>
	         </div>
	        </div>
	    </div>
	</header>



