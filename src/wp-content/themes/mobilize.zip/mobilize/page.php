<?php get_header(); ?>
	
	<div class="container">
		<div class="row miolo">
			<div class="span4 sidebar">
				<?php get_sidebar(); ?>
			</div>
			
			<div class="span8 conteudo">
			<h2> <?php the_title(); ?> </h2>
			
			 <?php the_post(); ?>
			 <?php the_content(); ?>
			 </div>
		</div>
	</div>
	
<?php get_footer(); ?>
